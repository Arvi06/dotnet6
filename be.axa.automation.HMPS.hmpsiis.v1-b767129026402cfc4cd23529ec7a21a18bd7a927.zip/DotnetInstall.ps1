﻿$URL = "https://stg.artifacts.axa.be/artifactory/devtools/dotnet/dotnet-hosting-6.0.11-win.exe"
$Destination = "C:\inetpub\temp"
$version = "6.0.11"
$DotNETCoreUpdatesPath = "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Updates\.NET" 
$DotNetCoreItems = Get-Item -ErrorAction Stop -Path $DotNETCoreUpdatesPath 
$NotInstalled = $True 
$DotNetCoreItems.GetSubKeyNames() | Where { $_ -Match "Microsoft .NET .*Windows Server Hosting" } | ForEach-Object { 
    $NotInstalled = $False 
    Write-Host "The host has already installed $_" 
	$okToDeploy = $true
} 
If ($NotInstalled) { 

    Write-Host "Can not find Microsoft.NET Hosting Bundle installed on the host"
    
    Write-Host "Installing .NET Hosting Bundle"
    Invoke-WebRequest -Uri $URL -OutFile $Destination\dotnet-hosting-$version-win.exe
    Write-Host "Successfully Installed .NET Hosting Bundle"

    Write-Host "Running .exe file"
    cd "$Destination" 
    ./dotnet-hosting-$version-win.exe /S /v /qn
} 
