﻿

[CmdletBinding()]
 Param(
   [Parameter(Mandatory=$True)]
    [string]$WebSiteName,
    [Parameter(Mandatory=$True)]
    [string]$WebsitePhysicalPath,
    [Parameter(Mandatory=$False)]
    [string]$DefaultAppPoolName
 )
 import-module WebAdministration

 $iisWebsiteBindings = @(  
   @{protocol="http";bindingInformation="*:80:"}
   )

  
 Write-Host $WebSiteName
 Write-Host $WebsitePhysicalPath
 Write-Host $DefaultAppPoolName

 if(-not $DefaultAppPoolName){
 $DefaultAppPoolName = $WebSiteName}

 

 Function CreateAppPool {
         Param([string] $DefaultAppPoolName)
 
         if(Test-Path ("IIS:\AppPools\" + $DefaultAppPoolName)) {
             Write-Host "The App Pool $DefaultAppPoolName already exists" -ForegroundColor Yellow
             return
         }
 
         else {
            New-Item IIS:/AppPools/$DefaultAppPoolName
            Set-ItemProperty IIS:/AppPools/$DefaultAppPoolName -name "managedRuntimeVersion" -value "v4.0"  
            Write-Host "App Pool $DefaultAppPoolName has been created Successfully"
      }  
     }
 
 function CreatePhysicalPath {
     Param([string] $WebsitePhysicalPath)
     
     if(Test-path $WebsitePhysicalPath) {
         Write-Host "The folder $WebsitePhysicalPath already exists" -ForegroundColor Yellow
         return
         }
     else{
         New-Item -ItemType directory -Path $WebsitePhysicalPath -Force
        }
 }


  CreatePhysicalPath $WebsitePhysicalPath
  CreateAppPool $DefaultAppPoolName
  If(!(Test-Path "IIS:\Sites\$WebSiteName")){
        New-Item IIS:\Sites\$WebSiteName -bindings $iisWebsiteBindings -PhysicalPath $WebsitePhysicalPath
        Set-ItemProperty IIS:/Sites/$WebSiteName -name ApplicationPool -value $DefaultAppPoolName
        Write-Host "IIS Site $WebSiteName has been created Successfully"
          }
      else {
          Write-Host "The IIS site $WebSiteName already exists" -ForegroundColor Yellow
          exit
      }
